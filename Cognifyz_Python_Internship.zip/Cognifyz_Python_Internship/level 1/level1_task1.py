def reverse_string(word):
    return word[::-1]

word = input("Enter a word: ")
print("Reversed word:", reverse_string(word))