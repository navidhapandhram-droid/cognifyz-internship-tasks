
import string

filename = input("Enter the text filename: ")

try:
    with open(filename, "r") as file:
        text = file.read()

    for symbol in string.punctuation:
        text = text.replace(symbol, "")

    words = text.lower().split()
    word_count = {}

    for word in words:
        word_count[word] = word_count.get(word, 0) + 1

    print("\nWord Counts (Alphabetical Order):")

    for word in sorted(word_count):
        print(word, ":", word_count[word])

except FileNotFoundError:
    print("File not found. Please check the filename.")
    