
def fibonacci(n):
    a, b = 0, 1

    for i in range(n):
        print(a, end=" ")
        a, b = b, a + b

    print()


terms = int(input("Enter the number of terms: "))

if terms <= 0:
    print("Please enter a positive number.")
else:
    print("Fibonacci sequence:")
    fibonacci(terms)
    