
def check_password(password):
    score = 0

    if len(password) >= 8:
        score += 1
    if any(char.isupper() for char in password):
        score += 1
    if any(char.islower() for char in password):
        score += 1
    if any(char.isdigit() for char in password):
        score += 1
    if any(not char.isalnum() for char in password):
        score += 1

    if score <= 2:
        return "Weak password"
    elif score <= 4:
        return "Moderate password"
    else:
        return "Strong password"


password = input("Enter your password: ")
print(check_password(password))

        
        