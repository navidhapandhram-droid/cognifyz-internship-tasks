
import random

number = random.randint(1, 50)
attempts = 0

print("Number Guesser")
print("Guess a number between 1 and 50.")

while True:
    guess = int(input("Enter your guess: "))
    attempts += 1

    if guess < number:
        print("Your guess is too low.")
    elif guess > number:
        print("Your guess is too high.")
    else:
        print("Correct! You guessed the number.")
        print("Total attempts:", attempts)
        break
        
        